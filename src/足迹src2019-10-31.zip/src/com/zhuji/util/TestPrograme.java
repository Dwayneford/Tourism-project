package com.zhuji.util;

import com.zhuji.dao.impl.dingdanpingjiaImpl;
import com.zhuji.dao.impl.jingdiantupianImpl;
import com.zhuji.dao.impl.xingchengImpl;
import com.zhuji.entity.Edingdanpingjia;
import com.zhuji.entity.Ejingdiantupian;
import com.zhuji.entity.Exingcheng;

public class TestPrograme {
	public static void main(String[] args) {
	/**********************dingdanpingjiaImpl测试模块********************************/
		Edingdanpingjia Ejdpj = new Edingdanpingjia(12345,789,445, "评价测试","2019");
		dingdanpingjiaImpl ddpj = new dingdanpingjiaImpl();
		//ddpj.add(Ejdpj);
		/*for (int i = 0; i < 5; i++) {
			ddpj.addorup(Ejdpj);
		}*/
		ddpj.remove(789);
		/*System.out.println(ddpj.ShowAll());
		ddpj.Up(Ejdpj);*/
		System.out.println(ddpj.qurtlistbyuser_ID(445));
		System.out.println(ddpj.ShowAll());
	/***********************dingdanpingjiaImpl测试结束*******************************/
		
	/**********************xingchengImpl测试模块********************************/
		Exingcheng Exc = new Exingcheng(8977,"徐凤年","success","45","jgk","sss","tyyt","tyty");
		xingchengImpl xc = new xingchengImpl();
		//xc.add(Exc); //添加方法
		System.out.println(xc.qurtlistBytixingD("tixing"));
		//xc.remove(1);
	/***********************xingchengImpl测试结束*******************************/
		
	/**********************jingdiantupianImpl测试模块********************************/
		Ejingdiantupian Ejdtp = new Ejingdiantupian(3123,12112,"D://image.jpg");
		jingdiantupianImpl ddtpj = new jingdiantupianImpl();
//		ddtpj.add(Ejdtp);
		System.out.println(ddtpj.qurylistBytupian_ID(2123));
		ddtpj.remove(2135);
	/***********************dingdanpingjiaImpl测试结束*******************************/
	}
}
