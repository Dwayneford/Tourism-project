package com.zhuji.entity;
/**
 *  @author lhq
 */
public class Jingdian {
	private int jingdian_ID;
	private int tupian_ID;
	private String mingcheng;
	private String dizhi;
	private String miaosu;
	public Jingdian(int jingdian_ID, int tupian_ID, String mingcheng, String dizhi, String miaosu) {
		super();
		this.jingdian_ID = jingdian_ID;
		this.tupian_ID = tupian_ID;
		this.mingcheng = mingcheng;
		this.dizhi = dizhi;
		this.miaosu = miaosu;
	}
	public Jingdian() {
		super();
	}
	public int getJingdian_ID() {
		return jingdian_ID;
	}
	public void setJingdian_ID(int jingdian_ID) {
		this.jingdian_ID = jingdian_ID;
	}
	public int getTupian_ID() {
		return tupian_ID;
	}
	public void setTupian_ID(int tupian_ID) {
		this.tupian_ID = tupian_ID;
	}
	public String getMingcheng() {
		return mingcheng;
	}
	public void setMingcheng(String mingcheng) {
		this.mingcheng = mingcheng;
	}
	public String getDizhi() {
		return dizhi;
	}
	public void setDizhi(String dizhi) {
		this.dizhi = dizhi;
	}
	public String getMiaosu() {
		return miaosu;
	}
	public void setMiaosu(String miaosu) {
		this.miaosu = miaosu;
	}
	public Jingdian(int tupian_ID, String mingcheng, String dizhi, String miaosu) {
		super();
		this.tupian_ID = tupian_ID;
		this.mingcheng = mingcheng;
		this.dizhi = dizhi;
		this.miaosu = miaosu;
	}
	@Override
	public String toString() {
		return "Jingdian [jingdian_ID=" + jingdian_ID + ", tupian_ID=" + tupian_ID + ", mingcheng=" + mingcheng
				+ ", dizhi=" + dizhi + ", miaosu=" + miaosu + "]";
	}

}
