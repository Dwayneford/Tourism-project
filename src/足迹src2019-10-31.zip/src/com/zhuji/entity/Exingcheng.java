package com.zhuji.entity;
	/**
	 * @author xxy
	 *@time 2019-10-24*/
public class Exingcheng {
	private int xingcheng_ID;
	private int xianlu_ID;
	private String kaishi_time;
	private String jiesu_time;
	private String renshu;
	private String zhuangtai;
	private String jiage;
	private String shuoming;
	private String tixing;
	public int getXingcheng_ID() {
		return xingcheng_ID;
	}
	public void setXingcheng_ID(int xingcheng_ID) {
		this.xingcheng_ID = xingcheng_ID;
	}
	public int getXianlu_ID() {
		return xianlu_ID;
	}
	public void setXianlu_ID(int xianlu_ID) {
		this.xianlu_ID = xianlu_ID;
	}
	public String getKaishi_time() {
		return kaishi_time;
	}
	public void setKaishi_time(String kaishi_time) {
		this.kaishi_time = kaishi_time;
	}
	public String getJiesu_time() {
		return jiesu_time;
	}
	public void setJiesu_time(String jiesu_time) {
		this.jiesu_time = jiesu_time;
	}
	public String getRenshu() {
		return renshu;
	}
	public void setRenshu(String renshu) {
		this.renshu = renshu;
	}
	public String getZhuangtai() {
		return zhuangtai;
	}
	public void setZhuangtai(String zhuangtai) {
		this.zhuangtai = zhuangtai;
	}
	public String getJiage() {
		return jiage;
	}
	public void setJiage(String jiage) {
		this.jiage = jiage;
	}
	public String getShuoming() {
		return shuoming;
	}
	public void setShuoming(String shuoming) {
		this.shuoming = shuoming;
	}
	public String getTixing() {
		return tixing;
	}
	public void setTixing(String tixing) {
		this.tixing = tixing;
	}
	/**
	 * 
	 */
	public Exingcheng() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param xianlu_ID
	 * @param kaishi_time
	 * @param jiesu_time
	 * @param renshu
	 * @param zhuangtai
	 * @param jiage
	 * @param shuoming
	 * @param tixing
	 */
	public Exingcheng(int xianlu_ID, String kaishi_time, String jiesu_time, String renshu, String zhuangtai,
			String jiage, String shuoming, String tixing) {
		this.xianlu_ID = xianlu_ID;
		this.kaishi_time = kaishi_time;
		this.jiesu_time = jiesu_time;
		this.renshu = renshu;
		this.zhuangtai = zhuangtai;
		this.jiage = jiage;
		this.shuoming = shuoming;
		this.tixing = tixing;
	}
	@Override
	public String toString() {
		return "Exingcheng [xianlu_ID=" + xianlu_ID + ", kaishi_time=" + kaishi_time + ", jiesu_time=" + jiesu_time
				+ ", renshu=" + renshu + ", zhuangtai=" + zhuangtai + ", jiage=" + jiage + ", shuoming=" + shuoming
				+ ", tixing=" + tixing + "]";
	}
}
