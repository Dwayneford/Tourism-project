package com.zhuji.entity;
/**
 *  @author lhq
 */
public class Xainlu_jingdain_guanxi {
	
	private int ID;
	private int xianlu_ID;
	private int jingdian_ID;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getXianlu_ID() {
		return xianlu_ID;
	}
	public void setXianlu_ID(int xianlu_ID) {
		this.xianlu_ID = xianlu_ID;
	}
	public int getJingdian_ID() {
		return jingdian_ID;
	}
	public void setJingdian_ID(int jingdian_ID) {
		this.jingdian_ID = jingdian_ID;
	}
	public Xainlu_jingdain_guanxi(int iD, int xianlu_ID, int jingdian_ID) {
		super();
		ID = iD;
		this.xianlu_ID = xianlu_ID;
		this.jingdian_ID = jingdian_ID;
	}
	public Xainlu_jingdain_guanxi() {
		super();
	}
	public Xainlu_jingdain_guanxi(int xianlu_ID, int jingdian_ID) {
		super();
		this.xianlu_ID = xianlu_ID;
		this.jingdian_ID = jingdian_ID;
	}
	@Override
	public String toString() {
		return "Xainlu_jingdain_guanxi [ID=" + ID + ", xianlu_ID=" + xianlu_ID + ", jingdian_ID=" + jingdian_ID + "]";
	}

}
