package com.zhuji.entity;
/**
 *  @author lhq
 */
public class Xianlu {
	//��·
	private int xianlu_ID;
	private int jingdian_ID;
	private String pingjia;
	public int getXianlu_ID() {
		return xianlu_ID;
	}
	public void setXianlu_ID(int xianlu_ID) {
		this.xianlu_ID = xianlu_ID;
	}
	public int getJingdian_ID() {
		return jingdian_ID;
	}
	public void setJingdian_ID(int jingdian_ID) {
		this.jingdian_ID = jingdian_ID;
	}
	public String getPingjia() {
		return pingjia;
	}
	public void setPingjia(String pingjia) {
		this.pingjia = pingjia;
	}
	public Xianlu(int xianlu_ID, int jingdian_ID, String pingjia) {
		super();
		this.xianlu_ID = xianlu_ID;
		this.jingdian_ID = jingdian_ID;
		this.pingjia = pingjia;
	}
	public Xianlu() {
		super();
	}
	public Xianlu(int jingdian_ID, String pingjia) {
		super();
		this.jingdian_ID = jingdian_ID;
		this.pingjia = pingjia;
	}
	@Override
	public String toString() {
		return "Xianlu [xianlu_ID=" + xianlu_ID + ", jingdian_ID=" + jingdian_ID + ", pingjia=" + pingjia + "]";
	}

}
