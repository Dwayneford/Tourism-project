package com.zhuji.entity;
	/**
	 * @author xxy
	 *@time 2019-10-24*/
public class Ejingdian {
	private int jingdaian_ID;  //景点Id
	private int tupian_ID;  
	private String mingcheng;
	private String dizhi;
	private String miaosu;
	public int getJingdaian_ID() {
		return jingdaian_ID;
	}
	public void setJingdaian_ID(int jingdaian_ID) {
		this.jingdaian_ID = jingdaian_ID;
	}
	public int getTupian_ID() {
		return tupian_ID;
	}
	public void setTupian_ID(int tupian_ID) {
		this.tupian_ID = tupian_ID;
	}
	public String getMingcheng() {
		return mingcheng;
	}
	public void setMingcheng(String mingcheng) {
		this.mingcheng = mingcheng;
	}
	public String getDizhi() {
		return dizhi;
	}
	public void setDizhi(String dizhi) {
		this.dizhi = dizhi;
	}
	public String getMiaosu() {
		return miaosu;
	}
	public void setMiaosu(String miaosu) {
		this.miaosu = miaosu;
	}
	/**
	 * 
	 */
	public Ejingdian() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param jingdaian_ID
	 * @param tupian_ID
	 * @param mingcheng
	 * @param dizhi
	 * @param miaosu
	 */
	public Ejingdian(int jingdaian_ID, int tupian_ID, String mingcheng, String dizhi, String miaosu) {
		this.jingdaian_ID = jingdaian_ID;
		this.tupian_ID = tupian_ID;
		this.mingcheng = mingcheng;
		this.dizhi = dizhi;
		this.miaosu = miaosu;
	}
	
}
