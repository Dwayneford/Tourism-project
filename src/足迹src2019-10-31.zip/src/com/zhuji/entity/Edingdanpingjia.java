package com.zhuji.entity;
	/**
	 * @author xxy
	 *@time 2019-10-24*/
public class Edingdanpingjia {
	private int pinjia_ID;
	private int jingdian_ID;
	private int xingcheng_ID;
	private int user_ID;
	private String pingjia;
	private String pingjia_time;
	public int getPinjia_ID() {
		return pinjia_ID;
	}
	public void setPinjia_ID(int pinjia_ID) {
		this.pinjia_ID = pinjia_ID;
	}
	public int getJingdian_ID() {
		return jingdian_ID;
	}
	public void setJingdian_ID(int jingdian_ID) {
		this.jingdian_ID = jingdian_ID;
	}
	public int getXingcheng_ID() {
		return xingcheng_ID;
	}
	public void setXingcheng_ID(int xingcheng_ID) {
		this.xingcheng_ID = xingcheng_ID;
	}
	public int getUser_ID() {
		return user_ID;
	}
	public void setUser_ID(int user_ID) {
		this.user_ID = user_ID;
	}
	public String getPingjia() {
		return pingjia;
	}
	public void setPingjia(String pingjia) {
		this.pingjia = pingjia;
	}
	public String getPingjia_time() {
		return pingjia_time;
	}
	public void setPingjia_time(String pingjia_time) {
		this.pingjia_time = pingjia_time;
	}
	/**
	 * 
	 */
	public Edingdanpingjia() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @param jingdian_ID
	 * @param xingcheng_ID
	 * @param user_ID
	 * @param pingjia
	 * @param pingjia_time
	 */
	public Edingdanpingjia(int jingdian_ID, int xingcheng_ID, int user_ID, String pingjia, String pingjia_time) {
		this.jingdian_ID = jingdian_ID;
		this.xingcheng_ID = xingcheng_ID;
		this.user_ID = user_ID;
		this.pingjia = pingjia;
		this.pingjia_time = pingjia_time;
	}
	@Override
	public String toString() {
		return "Edingdanpingjia [pinjia_ID=" + pinjia_ID + ", jingdian_ID=" + jingdian_ID + ", xingcheng_ID=" + xingcheng_ID
				+ ", user_ID=" + user_ID + ", pingjia=" + pingjia + ", pingjia_time=" + pingjia_time + "]";
	}
}
