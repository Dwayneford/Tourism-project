package com.zhuji.entity;
/**
 * 
 * @author DYB
 *
 */
public class Hezuoshangjia {

	private int shangjia_ID;	//商家ID
	private String mingcheng;	//商家名称
	private String leixing;		//商家类型（酒店，卖场，农家乐）
	private String dianhua;		//电话
	private String zhuangtai;	//状态
	private String dizhi;		//地址
	private int jingdian_ID;	//景点ID
	private int tupianID;		//图片ID
	private String jieshao;		//介绍
	private String hezuoshijian;//合作时间
	private String junjia;		//均价
	public Hezuoshangjia(int shangjia_ID, String mingcheng, String leixing, String dianhua, String zhuangtai,
			String dizhi, int jingdian_ID, int tupianID, String jieshao, String hezuoshijian, String junjia) {
		super();
		this.shangjia_ID = shangjia_ID;
		this.mingcheng = mingcheng;
		this.leixing = leixing;
		this.dianhua = dianhua;
		this.zhuangtai = zhuangtai;
		this.dizhi = dizhi;
		this.jingdian_ID = jingdian_ID;
		this.tupianID = tupianID;
		this.jieshao = jieshao;
		this.hezuoshijian = hezuoshijian;
		this.junjia = junjia;
	}
	public Hezuoshangjia() {
		super();
	}
	public Hezuoshangjia(String mingcheng, String leixing, String dianhua, String zhuangtai, String dizhi,
			int jingdian_ID, int tupianID, String jieshao, String hezuoshijian, String junjia) {
		super();
		this.mingcheng = mingcheng;
		this.leixing = leixing;
		this.dianhua = dianhua;
		this.zhuangtai = zhuangtai;
		this.dizhi = dizhi;
		this.jingdian_ID = jingdian_ID;
		this.tupianID = tupianID;
		this.jieshao = jieshao;
		this.hezuoshijian = hezuoshijian;
		this.junjia = junjia;
	}
	@Override
	public String toString() {
		return "Hezuoshangjia [shangjia_ID=" + shangjia_ID + ", mingcheng=" + mingcheng + ", leixing=" + leixing
				+ ", dianhua=" + dianhua + ", zhuangtai=" + zhuangtai + ", dizhi=" + dizhi + ", jingdian_ID="
				+ jingdian_ID + ", tupianID=" + tupianID + ", jieshao=" + jieshao + ", hezuoshijian=" + hezuoshijian
				+ ", junjia=" + junjia + "]";
	}
	public int getShangjia_ID() {
		return shangjia_ID;
	}
	public void setShangjia_ID(int shangjia_ID) {
		this.shangjia_ID = shangjia_ID;
	}
	public String getMingcheng() {
		return mingcheng;
	}
	public void setMingcheng(String mingcheng) {
		this.mingcheng = mingcheng;
	}
	public String getLeixing() {
		return leixing;
	}
	public void setLeixing(String leixing) {
		this.leixing = leixing;
	}
	public String getDianhua() {
		return dianhua;
	}
	public void setDianhua(String dianhua) {
		this.dianhua = dianhua;
	}
	public String getZhuangtai() {
		return zhuangtai;
	}
	public void setZhuangtai(String zhuangtai) {
		this.zhuangtai = zhuangtai;
	}
	public String getDizhi() {
		return dizhi;
	}
	public void setDizhi(String dizhi) {
		this.dizhi = dizhi;
	}
	public int getJingdian_ID() {
		return jingdian_ID;
	}
	public void setJingdian_ID(int jingdian_ID) {
		this.jingdian_ID = jingdian_ID;
	}
	public int getTupianID() {
		return tupianID;
	}
	public void setTupianID(int tupianID) {
		this.tupianID = tupianID;
	}
	public String getJieshao() {
		return jieshao;
	}
	public void setJieshao(String jieshao) {
		this.jieshao = jieshao;
	}
	public String getHezuoshijian() {
		return hezuoshijian;
	}
	public void setHezuoshijian(String hezuoshijian) {
		this.hezuoshijian = hezuoshijian;
	}
	public String getJunjia() {
		return junjia;
	}
	public void setJunjia(String junjia) {
		this.junjia = junjia;
	}
	
	
	
	
	
	
}
