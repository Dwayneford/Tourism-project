package com.zhuji.entity;
	/**
	 * @author xxy
	 *@time 2019-10-25*/
public class Ejingdiantupian {
	private int tupian_ID;
	private int jingdian_ID;
	private String tupianURL;
	public int getTupian_ID() {
		return tupian_ID;
	}
	public void setTupian_ID(int tupian_ID) {
		this.tupian_ID = tupian_ID;
	}
	public int getJingdian_ID() {
		return jingdian_ID;
	}
	public void setJingdian_ID(int jingdian_ID) {
		this.jingdian_ID = jingdian_ID;
	}
	public String getTupianURL() {
		return tupianURL;
	}
	public void setTupianURL(String tupianURL) {
		this.tupianURL = tupianURL;
	}
	/**
	 * 
	 */
	public Ejingdiantupian() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @param tupian_ID
	 * @param jingdian_ID
	 * @param tupianURL
	 */
	public Ejingdiantupian(int tupian_ID, int jingdian_ID, String tupianURL) {
		this.tupian_ID = tupian_ID;
		this.jingdian_ID = jingdian_ID;
		this.tupianURL = tupianURL;
	}
	
	/**
	 * @param jingdian_ID
	 * @param tupianURL
	 */
	public Ejingdiantupian(int jingdian_ID, String tupianURL) {
		this.jingdian_ID = jingdian_ID;
		this.tupianURL = tupianURL;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Ejingdiantupian[tupian_ID=" + tupian_ID + ", jingdian_ID=" + jingdian_ID + ", tupianURL=" + tupianURL+"]";
	}
	
}
