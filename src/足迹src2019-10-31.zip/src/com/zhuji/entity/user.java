package com.zhuji.entity;
/**
 * @author jiejie
 *@time 2019-10-24
 *
 **/
public class user {
	
	
	// Fields
	private Integer userId; //userid
	private String user_name; //用户名
	private String user_password; //密码
	private String user_mail; //邮箱
	private String user_telphone; //
	private String user_photo;//电话
	private String user_qq; //qq
	private String user_status; //状态
	private String user_remark; //
	private String user_createTime;; //时间
	private String user_sex; //性别
	private String user_happy; //生日
	private String user_adress; //地址
	public user(Integer userId, String user_name, String user_password, String user_mail, String user_telphone,
			String user_photo, String user_qq, String user_status, String user_remark, String user_createTime,
			String user_sex, String user_happy, String user_adress) {
		super();
		this.userId = userId;
		this.user_name = user_name;
		this.user_password = user_password;
		this.user_mail = user_mail;
		this.user_telphone = user_telphone;
		this.user_photo = user_photo;
		this.user_qq = user_qq;
		this.user_status = user_status;
		this.user_remark = user_remark;
		this.user_createTime = user_createTime;
		this.user_sex = user_sex;
		this.user_happy = user_happy;
		this.user_adress = user_adress;
	}
	public user(String user_name, String user_password, String user_mail, String user_telphone, String user_photo,
			String user_qq, String user_status, String user_remark, String user_createTime, String user_sex,
			String user_happy, String user_adress) {
		super();
		this.user_name = user_name;
		this.user_password = user_password;
		this.user_mail = user_mail;
		this.user_telphone = user_telphone;
		this.user_photo = user_photo;
		this.user_qq = user_qq;
		this.user_status = user_status;
		this.user_remark = user_remark;
		this.user_createTime = user_createTime;
		this.user_sex = user_sex;
		this.user_happy = user_happy;
		this.user_adress = user_adress;
	}
	public user() {
		super();
	}
	
	public user(String user_password, String user_telphone) {
		super();
		this.user_password = user_password;
		this.user_telphone = user_telphone;
	}
	public user(String user_name, String user_password, String user_telphone) {
		super();
		this.user_name = user_name;
		this.user_password = user_password;
		this.user_telphone = user_telphone;
	}
	public user(String user_name, String user_password, String user_mail, String user_telphone) {
		super();
		this.user_name = user_name;
		this.user_password = user_password;
		this.user_mail = user_mail;
		this.user_telphone = user_telphone;
	}
	@Override
	public String toString() {
		return "user [userId=" + userId + ", user_name=" + user_name + ", user_password=" + user_password
				+ ", user_mail=" + user_mail + ", user_telphone=" + user_telphone + ", user_photo=" + user_photo
				+ ", user_qq=" + user_qq + ", user_status=" + user_status + ", user_remark=" + user_remark
				+ ", user_createTime=" + user_createTime + ", user_sex=" + user_sex + ", user_happy=" + user_happy
				+ ", user_adress=" + user_adress + "]";
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_mail() {
		return user_mail;
	}
	public void setUser_mail(String user_mail) {
		this.user_mail = user_mail;
	}
	public String getuser_telphone() {
		return user_telphone;
	}
	public void setuser_telphone(String user_telphone) {
		this.user_telphone = user_telphone;
	}
	public String getUser_photo() {
		return user_photo;
	}
	public void setUser_photo(String user_photo) {
		this.user_photo = user_photo;
	}
	public String getUser_qq() {
		return user_qq;
	}
	public void setUser_qq(String user_qq) {
		this.user_qq = user_qq;
	}
	public String getUser_status() {
		return user_status;
	}
	public void setUser_status(String user_status) {
		this.user_status = user_status;
	}
	public String getUser_remark() {
		return user_remark;
	}
	public void setUser_remark(String user_remark) {
		this.user_remark = user_remark;
	}
	public String getUser_createTime() {
		return user_createTime;
	}
	public void setUser_createTime(String user_createTime) {
		this.user_createTime = user_createTime;
	}
	public String getUser_sex() {
		return user_sex;
	}
	public void setUser_sex(String user_sex) {
		this.user_sex = user_sex;
	}
	public String getUser_happy() {
		return user_happy;
	}
	public void setUser_happy(String user_happy) {
		this.user_happy = user_happy;
	}
	public String getUser_adress() {
		return user_adress;
	}
	public void setUser_adress(String user_adress) {
		this.user_adress = user_adress;
	}
	
	
	
	
}
