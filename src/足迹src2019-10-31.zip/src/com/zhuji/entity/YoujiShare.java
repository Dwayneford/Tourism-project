package com.zhuji.entity;

public class YoujiShare {
	
	private int youji_ID;
	private String youji_Adress;
	private String youji_time;
	private String youji_Share;
	public int getYouji_ID() {
		return youji_ID;
	}
	public void setYouji_ID(int youji_ID) {
		this.youji_ID = youji_ID;
	}
	public String getYouji_Adress() {
		return youji_Adress;
	}
	public void setYouji_Adress(String youji_Adress) {
		this.youji_Adress = youji_Adress;
	}
	public String getYouji_time() {
		return youji_time;
	}
	public void setYouji_time(String youji_time) {
		this.youji_time = youji_time;
	}
	public String getYouji_Share() {
		return youji_Share;
	}
	public void setYouji_Share(String youji_Share) {
		this.youji_Share = youji_Share;
	}
	public YoujiShare(int youji_ID, String youji_Adress, String youji_time, String youji_Share) {
		super();
		this.youji_ID = youji_ID;
		this.youji_Adress = youji_Adress;
		this.youji_time = youji_time;
		this.youji_Share = youji_Share;
	}
	public YoujiShare(String youji_Adress, String youji_time, String youji_Share) {
		super();
		this.youji_Adress = youji_Adress;
		this.youji_time = youji_time;
		this.youji_Share = youji_Share;
	}
	public YoujiShare(String youji_Share) {
		super();
		this.youji_Share = youji_Share;
	}
	public YoujiShare(int youji_ID, String youji_time, String youji_Share) {
		super();
		this.youji_ID = youji_ID;
		this.youji_time = youji_time;
		this.youji_Share = youji_Share;
	}
	
	

}
