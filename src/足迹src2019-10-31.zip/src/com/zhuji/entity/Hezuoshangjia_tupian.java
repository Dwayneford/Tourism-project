package com.zhuji.entity;
/**
 * 
 * @author DYB
 *
 */
public class Hezuoshangjia_tupian {
	private int tupian_ID;		//图片ID
	private int shangjia_ID;	//商家ID	
	private String tupianURL;	//图片链接
	
	public Hezuoshangjia_tupian(int shangjia_ID, String tupianURL) {
		super();
		this.shangjia_ID = shangjia_ID;
		this.tupianURL = tupianURL;
	}
	public Hezuoshangjia_tupian(int tupian_ID, int shangjia_ID, String tupianURL) {
		super();
		this.tupian_ID = tupian_ID;
		this.shangjia_ID = shangjia_ID;
		this.tupianURL = tupianURL;
	}
	public Hezuoshangjia_tupian() {
		super();
	}
	@Override
	public String toString() {
		return "Hezuoshangjia_tupian [tupian_ID=" + tupian_ID + ", shangjia_ID=" + shangjia_ID + ", tupianURL="
				+ tupianURL + "]";
	}
	public int getTupian_ID() {
		return tupian_ID;
	}
	public void setTupian_ID(int tupian_ID) {
		this.tupian_ID = tupian_ID;
	}
	public int getShangjia_ID() {
		return shangjia_ID;
	}
	public void setShangjia_ID(int shangjia_ID) {
		this.shangjia_ID = shangjia_ID;
	}
	public String getTupianURL() {
		return tupianURL;
	}
	public void setTupianURL(String tupianURL) {
		this.tupianURL = tupianURL;
	}
	
	
	
	
	
	
	
	
}
