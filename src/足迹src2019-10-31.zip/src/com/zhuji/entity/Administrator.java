package com.zhuji.entity;
/**
 * @author jiejie
 *@time 2019-10-25
 *
 **/

public class Administrator {

	// Fields

	private Integer admin_id;
	private String admin_name;
	private String admin_pwd;
	private String admin_role;
	private String admin_tel;
	private String admin_email;
	private String admin_photo_url;
	private String admin_time;

	// Constructors
	/** default constructor */
	public Administrator() {
	}

	/** minimal constructor */
	public Administrator(Integer admin_id) {
		this.admin_id = admin_id;
	}

	/** full constructor */
	public Administrator(Integer admin_id, String admin_name, String admin_pwd, String admin_role, String admin_tel,
			String admin_email, String admin_photo_url, String admin_time) {
		this.admin_id = admin_id;
		this.admin_name = admin_name;
		this.admin_pwd = admin_pwd;
		this.admin_role = admin_role;
		this.admin_tel = admin_tel;
		this.admin_email = admin_email;
		this.admin_photo_url = admin_photo_url;
		this.admin_time = admin_time;
	}
	// Property accessors

		public Integer getadmin_id() {
			return this.admin_id;
		}

		public Administrator(String admin_name, String admin_pwd, String admin_role, String admin_tel,
				String admin_email, String admin_photo_url, String admin_time) {
			super();
			this.admin_name = admin_name;
			this.admin_pwd = admin_pwd;
			this.admin_role = admin_role;
			this.admin_tel = admin_tel;
			this.admin_email = admin_email;
			this.admin_photo_url = admin_photo_url;
			this.admin_time = admin_time;
		}

		public Administrator(String admin_name, String admin_pwd, String admin_tel) {
		super();
		this.admin_name = admin_name;
		this.admin_pwd = admin_pwd;
		this.admin_tel = admin_tel;
	}

		public Administrator(String admin_name, String admin_pwd) {
			super();
			this.admin_name = admin_name;
			this.admin_pwd = admin_pwd;
		}

		public void setadmin_id(Integer admin_id) {
			this.admin_id = admin_id;
		}

		public String getadmin_name() {
			return this.admin_name;
		}

		public void setadmin_name(String admin_name) {
			this.admin_name = admin_name;
		}

		public String getadmin_pwd() {
			return this.admin_pwd;
		}

		public void setadmin_pwd(String admin_pwd) {
			this.admin_pwd = admin_pwd;
		}

		public String getadmin_role() {
			return this.admin_role;
		}

		public void setadmin_role(String admin_role) {
			this.admin_role = admin_role;
		}

		public String getadmin_tel() {
			return this.admin_tel;
		}

		public void setadmin_tel(String admin_tel) {
			this.admin_tel = admin_tel;
		}

		public String getadmin_email() {
			return this.admin_email;
		}

		public void setadmin_email(String admin_email) {
			this.admin_email = admin_email;
		}

		public String getadmin_photo_url() {
			return this.admin_photo_url;
		}

		public void setadmin_photo_url(String admin_photo_url) {
			this.admin_photo_url = admin_photo_url;
		}

		public String getadmin_timee() {
			return this.admin_time;
		}

		public void setadmin_time(String admin_time) {
			this.admin_time = admin_time;
		}

	}

