package com.zhuji.entity;

/**
 * 
 * @author jie
 *	用户订单类
 *
 */

public class Dindan {

	// 属性

	private int dingdan_ID;		//
	private String dingdan_NO;		//订单编号
	private int user_ID;		//用户
	private int xianlu_ID;		//线路ID
	private String zifu_time;		//支付时间
	private String zifu_NO;		//支付编号
	private String dindanzongjia;	
	private String zhuangtai;
	public Dindan(int dingdan_ID, String dingdan_NO, int user_ID, int xianlu_ID, String zifu_time, String zifu_NO,
			String dindanzongjia, String zhuangtai) {
		super();
		this.dingdan_ID = dingdan_ID;
		this.dingdan_NO = dingdan_NO;
		this.user_ID = user_ID;
		this.xianlu_ID = xianlu_ID;
		this.zifu_time = zifu_time;
		this.zifu_NO = zifu_NO;
		this.dindanzongjia = dindanzongjia;
		this.zhuangtai = zhuangtai;
	}
	public Dindan() {
		super();
	}
	public Dindan(String dingdan_NO, int user_ID, int xianlu_ID, String zifu_time, String zifu_NO, String dindanzongjia,
			String zhuangtai) {
		super();
		this.dingdan_NO = dingdan_NO;
		this.user_ID = user_ID;
		this.xianlu_ID = xianlu_ID;
		this.zifu_time = zifu_time;
		this.zifu_NO = zifu_NO;
		this.dindanzongjia = dindanzongjia;
		this.zhuangtai = zhuangtai;
	}
	public int getDingdan_ID() {
		return dingdan_ID;
	}
	public void setDingdan_ID(int dingdan_ID) {
		this.dingdan_ID = dingdan_ID;
	}
	public String getDingdan_NO() {
		return dingdan_NO;
	}
	public void setDingdan_NO(String dingdan_NO) {
		this.dingdan_NO = dingdan_NO;
	}
	public int getUser_ID() {
		return user_ID;
	}
	public void setUser_ID(int user_ID) {
		this.user_ID = user_ID;
	}
	public int getXianlu_ID() {
		return xianlu_ID;
	}
	public void setXianlu_ID(int xianlu_ID) {
		this.xianlu_ID = xianlu_ID;
	}
	public String getZifu_time() {
		return zifu_time;
	}
	public void setZifu_time(String zifu_time) {
		this.zifu_time = zifu_time;
	}
	public String getZifu_NO() {
		return zifu_NO;
	}
	public void setZifu_NO(String zifu_NO) {
		this.zifu_NO = zifu_NO;
	}
	public String getDindanzongjia() {
		return dindanzongjia;
	}
	public void setDindanzongjia(String dindanzongjia) {
		this.dindanzongjia = dindanzongjia;
	}
	public String getZhuangtai() {
		return zhuangtai;
	}
	public void setZhuangtai(String zhuangtai) {
		this.zhuangtai = zhuangtai;
	}
	@Override
	public String toString() {
		return "Dindan [dingdan_ID=" + dingdan_ID + ", dingdan_NO=" + dingdan_NO + ", user_ID=" + user_ID
				+ ", xianlu_ID=" + xianlu_ID + ", zifu_time=" + zifu_time + ", zifu_NO=" + zifu_NO + ", dindanzongjia="
				+ dindanzongjia + ", zhuangtai=" + zhuangtai + "]";
	}	
	
}