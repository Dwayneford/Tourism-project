package com.zhuji.entity;

public class Pinglun_tupian {
	private int ID;				//ID
	private int xingcheng_ID;	//行程ID
	private String tupianURL ;	//图片链接	
	private String zhuangtai;	//状态
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getXingcheng_ID() {
		return xingcheng_ID;
	}
	public void setXingcheng_ID(int xingcheng_ID) {
		this.xingcheng_ID = xingcheng_ID;
	}
	public String getTupianURL() {
		return tupianURL;
	}
	public void setTupianURL(String tupianURL) {
		this.tupianURL = tupianURL;
	}
	public String getZhuangtai() {
		return zhuangtai;
	}
	public void setZhuangtai(String zhuangtai) {
		this.zhuangtai = zhuangtai;
	}
	public Pinglun_tupian(int iD, int xingcheng_ID, String tupianURL, String zhuangtai) {
		super();
		ID = iD;
		this.xingcheng_ID = xingcheng_ID;
		this.tupianURL = tupianURL;
		this.zhuangtai = zhuangtai;
	}
	public Pinglun_tupian(int xingcheng_ID, String tupianURL, String zhuangtai) {
		super();
		this.xingcheng_ID = xingcheng_ID;
		this.tupianURL = tupianURL;
		this.zhuangtai = zhuangtai;
	}
	public Pinglun_tupian() {
		super();
	}
	
}
