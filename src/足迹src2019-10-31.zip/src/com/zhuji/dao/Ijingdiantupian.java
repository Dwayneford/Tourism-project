package com.zhuji.dao;

import java.util.List;

import com.zhuji.entity.Edingdanpingjia;
import com.zhuji.entity.Ejingdiantupian;

public interface Ijingdiantupian {
	
	/**
	 * 功能：通过行程Id表查询   方法：qurylistBytupian_ID() * 建立时间：19-10-24
	 * 功能：通过行程Id表查询   方法：qurylistByjingdian_ID() * 建立时间：19-10-25
	 * 功能：通过行程Id表查询   方法：qurylistBytupianURL() * 建立时间：19-10-25
	 * 功能：查询表前部数据   方法：qurylist()   * 建立时间：19-10-25*/
	
	public List<Ejingdiantupian> qurylistBytupian_ID(int tupian_ID);
	public List<Ejingdiantupian> qurylistByjingdian_ID(int jingdian_ID);
	public List<Ejingdiantupian> qurylistBytupianURL(String tupianURL);
	
	/**
	 * 功能：行程表修改
	 * 方法：addOrUp
	 * 建立时间：19-10-24*/
	public boolean addOrUp(Ejingdiantupian jdtpEnt);
	
	/**
	 * 功能：行程表删除
	 * 方法：remove()
	 * 建立时间：19-10-24*/
	
	public boolean remove(int tupian_ID);
	
	
	public List<Ejingdiantupian> ShowAll(); 
}
