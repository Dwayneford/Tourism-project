package com.zhuji.dao;

import java.util.List;

import com.zhuji.entity.Hezuoshangjia;

/**
 * 
 * @author dyb
 *	合作商家接口
 */
public interface IHezuoshangjia {
	//添加合作商家
	public boolean addHezuoshangjia(Hezuoshangjia hezuoshangjia);
	//删除商家
	public boolean deleteHezuoshangjia(String dianhua);
	//修改商家
	public boolean updataHezuoshangjia(String dianhua,Hezuoshangjia hezuoshangjia);
	
	//查询所有商家
	public List<Hezuoshangjia> queryHezuoshangjias();
	//按名称查询商家
	public List<Hezuoshangjia> queryHezuoshangjiaByName(String mingcheng);
	//按类型查询商家
	public List<Hezuoshangjia> queryHezuoshangjiaByType(String leixing);
}
