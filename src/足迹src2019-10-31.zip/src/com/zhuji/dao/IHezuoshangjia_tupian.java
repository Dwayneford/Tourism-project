package com.zhuji.dao;

import java.util.List;

import com.zhuji.entity.Hezuoshangjia;
import com.zhuji.entity.Hezuoshangjia_tupian;

/**
 * 
 * @author DYB
 *合作商家图片
 */
public interface IHezuoshangjia_tupian {
	//添加合作商家图片
	public boolean addHezuoshangjia_tupian(Hezuoshangjia_tupian hezuoshangjia_tupian);
	//删除商家图片
	public boolean deleteHezuoshangjia_tupian(int tupian_ID);
	//修改商家图片
	public boolean updataHezuoshangjia_tupian(int tupian_ID,Hezuoshangjia_tupian hezuoshangjia_tupian);
	
	//查询所有商家图片
	public List<Hezuoshangjia_tupian> queryHezuoshangjia_tupians();
	//按ID查询商家图片
	public Hezuoshangjia_tupian queryHezuoshangjia_tupianByID(int tupian_ID);
	
}


