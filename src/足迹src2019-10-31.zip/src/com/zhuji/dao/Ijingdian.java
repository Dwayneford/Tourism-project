package com.zhuji.dao;

import java.util.List;

import com.zhuji.entity.Ejingdian;

	/**
		 * @author xxy
		 *@time 2019-10-24*/
public interface Ijingdian {
	/**
	 * 功能：通过行程Id表查询
	 * 方法：qurtlist()
	 * 建立时间：19-10-24*/
	public List<Ejingdian> qurtlist(int jingdian_ID);
	
	/**
	 * 功能：行程表修改
	 * 方法：Up
	 * 建立时间：19-10-24*/
	public void Up(Ejingdian JDEnt);
	
	/**
	 * 功能：行程表修改
	 * 方法：add()
	 * 建立时间：19-10-24*/
	public void add(Ejingdian JDEnt);
	
	/**
	 * 功能：行程表删除
	 * 方法：remove()
	 * 建立时间：19-10-24*/
	
	public void remove(int jingdian_ID);
}
