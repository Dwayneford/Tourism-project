package com.zhuji.dao;

import java.util.List;

import com.zhuji.entity.Pinglun_tupian;
/**
 * 
 * @author DYB
 *
 */

public interface Ipinglun_tupian {
	//增加评论图片
	public boolean addPinglun_tupian(Pinglun_tupian pinglun_tupian);
	//删除评论图片
	public boolean deletePinglun_tupian(int ID);
	//修改评论图片
	public boolean updatePinglun_tupian(int ID ,Pinglun_tupian pinglun_tupian);
	//查询所有评论图片
	public List<Pinglun_tupian> queryPinglun_tupians();
	//按行程ID查询图片
	public Pinglun_tupian queryPinglun_tupianByxingcheng_ID(int xingcheng_ID);
	//按图片ID查询图片
	public Pinglun_tupian queryPinglun_tupianByID(int ID);
}
