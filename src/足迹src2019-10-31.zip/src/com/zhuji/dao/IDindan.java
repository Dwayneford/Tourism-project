package com.zhuji.dao;

import java.util.List;

import com.zhuji.entity.user;
import com.zhuji.entity.Dindan;

//订单功能接口
public interface IDindan {

	//添加订单
	public boolean addDindan(Dindan DindanEnt);
	//删除订单
	public boolean deleteDindan(String  dingdan_NO);
	//修改订单
	public boolean updateDindan(String dingdan_NO, Dindan userEnt);
	
	//查询所有订单
	public List<Dindan> queryDindans();
	//按订单号查询订单
	public Dindan querydingdanByDindan_NO(String dingdan_NO);


	
}
