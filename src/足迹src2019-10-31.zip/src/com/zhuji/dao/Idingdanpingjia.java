package com.zhuji.dao;

import java.util.List;

import com.zhuji.entity.Edingdanpingjia;

	/**
		 * @author xxy
		 *@time 2019-10-24*/
public interface Idingdanpingjia {
	/**
	 * 方法：qurtlistbypinjia_ID() 	* 功能：通过评价pinjia_ID表查询 	 * 建立时间：19-10-24
	 *方法：qurtlistbyjingdian_ID() 	* 功能：通过评价jingdian_ID表查询 	 * 建立时间：19-10-26
	 *方法：qurtlistbyxingcheng_ID() 	* 功能：通过评价xingcheng_ID表查询 	 * 建立时间：19-10-26
	 *方法：qurtlistbyuser_ID() 	* 功能：通过评价user_ID表查询 	 * 建立时间：19-10-26
	 *方法：qurtlistbypingjia() 	* 功能：通过评价pingjia表查询 	 * 建立时间：19-10-26
	 *方法：qurtlistbypingjia_time() 	* 功能：通过评价pingjia_time表查询 	 * 建立时间：19-10-26
	 **/
	public List<Edingdanpingjia> qurtlistbypinjia_ID(int pinjia_ID);
	public List<Edingdanpingjia> qurtlistbyjingdian_ID(int jingdian_ID);
	public List<Edingdanpingjia> qurtlistbyxingcheng_ID(int xingcheng_ID);
	public List<Edingdanpingjia> qurtlistbyuser_ID(int user_ID);
	public List<Edingdanpingjia> qurtlistbypingjia(String pingjia);
	public List<Edingdanpingjia> qurtlistbypingjia_time(String pingjia_time);

	/**
	 * 功能：显示全部信息
	 * 方法：ShowAll()
	 * 建立时间：19-10-26*/
	public List<Edingdanpingjia> ShowAll();
	
	/**
	 * 功能：评价表修改
	 * 方法：addOrUp()
	 * 建立时间：19-10-24*/
	
	public boolean addOrUp(Edingdanpingjia ddpj);
	
	
	/**
	 * 功能：通过评价Id 删除评价表
	 * 方法：remove()
	 * 建立时间：19-10-24*/
	
	public boolean remove(int pinjia_ID);

}
