package com.zhuji.dao;

import java.util.List;

import com.zhuji.entity.Exingcheng;

	/**
		 * @author xxy
		 *@time 2019-10-24*/
public interface Ixingcheng {
	/**
	 * 功能：通过行程xingcheng_ID表查询 * 方法：qurtlistByxingcheng_ID() 	* 建立时间：19-10-24
	 *功能：通过行程xianlu_ID表查询 * 方法：qurtlistByxianlu_ID() 	* 建立时间：19-10-25
	 *功能：通过行程kaishi_time表查询 * 方法：qurtlistBykaishi_time() 	* 建立时间：19-10-25
	 *功能：通过行程jiesu_time表查询 * 方法：qurtlistByjiesu_time() 	* 建立时间：19-10-25
	 *功能：通过行程renshu表查询 * 方法：qurtlistByrenshu() 	* 建立时间：19-10-25
	 *功能：通过行程zhuangtai表查询 * 方法：qurtlistByzhuangtai() 	* 建立时间：19-10-25
	 *功能：通过行程jiage表查询 * 方法：qurtlistByjiage() 	* 建立时间：19-10-25
	 *功能：通过行程shuoming表查询 * 方法：qurtlistByshuoming() 	* 建立时间：19-10-25
	 *功能：通过行程tixing表查询 * 方法：qurtlistBytixing() 	* 建立时间：19-10-25
	 *功能：表查询全部数据       * 方法:showAllList() 	* 建立时间：19-10-25 */
	
	public List<Exingcheng> qurtlistByxingcheng_ID(int xingcheng_ID);
	public List<Exingcheng> qurtlistByxianlu_ID(int xianlu_ID);
	public List<Exingcheng> qurtlistBykaishi_time(String kaishi_time);
	public List<Exingcheng> qurtlistByjiesu_time(String jiesu_time);
	public List<Exingcheng> qurtlistqurtlistByrenshu(String renshu);
	public List<Exingcheng> qurtlistByzhuangtai(String zhuangtai);
	public List<Exingcheng> qurtlistByjiage(String jiage);
	public List<Exingcheng> qurtlistByshuoming(String shuoming);
	public List<Exingcheng> qurtlistBytixingD(String tixing);
	public List<Exingcheng> showAllList();
	
	/**
	 * 功能：行程表修改，添加 保存
	 * 方法：UpAdd()
	 * 建立时间：19-10-24*/
	public boolean addOrUp(Exingcheng XCEnt);

	/**
	 * 功能：行程表删除
	 * 方法：remove()
	 * 建立时间：19-10-24*/
	
	public boolean remove(int xingcheng_ID);
}
