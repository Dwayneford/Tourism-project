package com.zhuji.dao;

import java.util.List;

import com.zhuji.entity.Xainlu_jingdain_guanxi;
import com.zhuji.entity.Xianlu;
/**
 *  @author lhq
 */
public interface IXainlu_jingdain_guanxi {
	
	        //������·�����ϵ
			public boolean addguanxi(Xainlu_jingdain_guanxi  guanxi);
			//ɾ��
			public boolean deleteguanxi(int ID);
			//�޸�
			public boolean updataguanxi(int ID,Xainlu_jingdain_guanxi  guanxi);		
			//��ѯ����
			public List<Xainlu_jingdain_guanxi> queryguanxi();
//			//�����Ʋ�ѯ
//			public List<Xainlu_jingdain_guanxi> queryguanxiName(int xianlu_ID);

}
