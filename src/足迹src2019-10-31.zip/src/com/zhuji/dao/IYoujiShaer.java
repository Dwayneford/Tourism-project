package com.zhuji.dao;

import java.util.List;

import com.zhuji.entity.YoujiShare;



public interface IYoujiShaer {
	
	        //����
			public boolean addYoujiShare(YoujiShare youjiShare);
			//ɾ��
			public boolean deleteYoujiShare(int youji_ID);
			//�޸�
			public boolean updataJindian( int youji_ID,YoujiShare youjiShare);
			
			//��ѯ����
			public List<YoujiShare> queryYoujiShare();
			//����ַ��ѯ����
			//public List<YoujiShare> queryJindianByName(String youji_Adress);

}
