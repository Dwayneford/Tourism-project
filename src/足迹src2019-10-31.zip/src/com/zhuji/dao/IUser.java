package com.zhuji.dao;

import java.util.List;

import com.zhuji.entity.user;
/**
 * 
 * @author jie
 * 
 *	用户功能接口
 */
public interface IUser {

	//添加用户
	public boolean addUser(user userEnt);
	//删除用户
	public boolean deleteUser(String user_phone);
	//修改用户
	public boolean updateUser(int userId , user userEnt);
	
	//查询所有用户
	public List<user> queryUsers();
	//按邮箱查询用户
	public user queryUserByMail(String user_mail);
	//按手机号查询用户
	public user queryUserByPhone(String user_telphon);
}
