﻿package com.alipay.config;

import java.io.FileWriter;
import java.io.IOException;

/* *
 *类名：AlipayConfig
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *修改日期：2017-04-05
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 *
 *  ALIPAY_PUBLIC_KEY=“填写的是支付宝的公钥，就是你配置完自己的公钥后生成的支付宝公钥，在网页上的”       
 *  APP_ID=“沙箱的APP_ID”   
 *  PRIVATE_KEY="是在生成公钥的同时，生成的packs8的私钥，在自己的文件夹可以找到"    
 *  PUBLIC_KEY=“这就是刚配置的公钥了”   
 *  ALIPAY_GATEWAY=“这个一定要注意了。这个要改成测试环境的网关，

 *
 */

public class AlipayConfig {
	
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

	// 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号
	public static String app_id = "2016101300675143";
	
	// 商户私钥，您的PKCS8格式RSA2私钥
	//public static String merchant_private_key = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC1Efnm7TkRG9p/piPKBa2XD6Ita6jMsu5BDSZt8RVY4lBsQu4t7lP2PLpFo4auyOQXv3F+fmCEtxz5I4nuvtqtnQKe+ysZnPdR5vBZA23hNs8qoSI3tOZ54lrY6WHy/1JPYAgwP/7fuowLdpSbeG+3vMCDejuf+Pj23a5oceQ4eFbRGPq4tkeC9YUx9MEOmMNDvZiQ7nozA3hgFsuDevOiiLRQa3J8cElO1XAgPOa+JYGV27V6NVh2yR21fH/H5kfCBckquryHQ/rMGjyTvrMHP0e/nk7lyieANQxkxPteF/LLtBXXkChmcFxi84gC0nduVy0B39Y/FYnjgVgb8r71AgMBAAECggEAA72tVhIMncfficea8a+QWJCgHyQcRq5jscBdzOOwNzflxXbUiOplna6/gnTQcYgA/mScKarev58w4AzV6rLSvceCqFo0F8Fgcra8vHoPqRmCyjSuCkyYfmgozFZ2CZkw0CcBxE1uLJ0kC5CVnWitljQ2HgFGfhWcvyzxT4Ma3ffFnfBetzd9htfrFLYNhXYxvCrXlgGWCuCpkVeJwo7lfvEsmpBCMepgqC6Fr1Ck53X5loK1AvD4RfG7nuua20iK7y6/WvC3v9uozwcYDXJPtKYzvZmsK7c28iLOuE33RdD2AJcNolMEaY+kzHfVsGIhDf68KrQF45HHLi/eCGWROQKBgQDXgLXquJLRLFeGdFEKLGE2PCFLVTNp04DkiNs6zJGu+WicYl9G3XYR9al3ulJ0NyCEKr5mUuWTwBjgiwX1vEUyxKgQdSmDluGSZZqBpiqlPyiTN5wGcE4ZxvCglyatsX4jPiH8C5GMmLT7A96Gg4Mdd1cw2iv7ybNXFS8FRY7MqwKBgQDXGM2S6iribEaoyMTyV9834U81QAv5+ahOo/mPj9a6q6VIwmYGJv/HsQ4fYI9GQ+w2bPMMShqZbtdE+7hgqQxuqRnu15YB///3NPstZuRhKy2yrY482i+LY3n0eq0heSE4ARTk+aBQEQeyRaCCZsPsqMPUjoU69gOFn/2UNJ9i3wKBgQCrF23Wd0lgtkKa5bf9SrS3OU/5niAecaPQTPM4oHc9IpgyKEuaWHLH2XD9NDkIOUgghkr5s/C+t/FIPDe0HBAYOVdxEYOvDFf0QaREMGeFIDqXfrvpxLnM70vVQ4uatOL/GfIjSA/7PrXY3/6Ibtrmxvu7NktbMIyoo5HcLpgr1wKBgAFOZ0EzJtuFKNCxl3CZVAO03JRINUppV7pSiJt0litAC5rrg08aQYdm7d0G6xfUJcUW2EsE0DCKWchTdwUvQaISaNPof0K32UgZDEV0UIK+jmJ9Z1W7RXqlOgJgFFkVsTvz1bqmQXD7CX7tqVHhaeMwCzBpRSncgJz5IcMaprUlAoGAU0pYZ3KRuRicJuGShsW/5e99eBWDa/XHWYz1B1g+NBL8Mk/iOo+tpOYInzeGYT+ZM96nB5IIb9Oj0/QyncuhAKLRkQCnWyQHOWo7s0CNRuIyloZctCE12A2Zkn6Y9VOiEKRJ0BbrKUD4zdQVYdfwCFH1+CXYJUSJKyiGpgJfuSI=";
    public static String merchant_private_key = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCpu6oRZpgZ0fDQ6mEX1eUlZGDnXCzG6KdiIjxqakCAaQRA6IrB9+STuLveYeRAF+RG4gcANLI3r46fdhDTK5Z+RCN5FyJ3oqZzvfz6V0BMHAsPQ4tZ4ZHOVjdxH/U1+uBdyEHCria4APXUEAehl8dssz4NfNW6Dl4FvXPHQxL4i0dHNPsrqsjIK1br/gR4AMzIsrSnzeWZCwEOSRnlYLv0OH9yu3VjIHiyhdr39CDi7qx0n0moGw1QYrUmN8JOV79vfmVinW2Qu/eELbjOLvjXU+gDhnc8q2qIH+Iy1qzWRRqDOBI4KWKWNV6Ya84UMDjVQwsFjSg9AeNHjAW7JjLBAgMBAAECggEBAItsdlT423RKOfDCtqLntuUyQU+LLdTug6Be0xXu1bElkrLm0iRnRsH5e4k/DEmB1qhLPsjygHqxoQxn5YYxRdvOiP0M/ekcGHL223mgdlaOqp8NMsjQO/8sXzpzr+95dxhSSYJrn66CS2y5Biu9C7nEuvJFWyMMbjt01kgWVt0F4LACRrHUhYfrUXtSev33vbgtVZaQNuiiFTg8HJ08gfRd37dyuxwmajqm5uGnbRxV3F/n6zoMN0EPYy5q9HapkGbysTyyES8DJZCTQoBZJRpz19TEMDIXF46CJP8odq/e/RHwStK4KJ0hkh12MWfICHFIkrQgeDjSywdv+ycavuECgYEA9VsuF5kS7+88TM+NRvlBEslDS/W+horHa1FUjoA2mL+XulTCZTKI+BDVIlUARJLjh194lu+FcSzoBtsVkfwVc/dfiAkoQGyWXLrauoKZf36vEDQETV+lqf1EFKrD5p/scdqHNU3lN9Npnz9EthMSxJCBIQ0e14+sn5SLkhaFgfUCgYEAsRiliK2d6I6YDD0LFpIDoAPQiwUs1ojrROLPo441IFHWE8FCorBQQYD/ITuWsKGOJtCO99+lyA2Sr0sEzlMf0qlhgV/LkBEJzVPkNRae0O6wpPt+1IgpZmRof0y4MeaLHkOavzVUZ64x3hxKyvon58eNta1bdCfJylxCW7MOUh0CgYBGEoVmbexPpBanpTsnAvbHw705i3SffjEYAEFS9WEiXM2bhKuENVuS5VPJm1cZPo5G0khhawTEXtvhYV6Ws9T4qrSY6Gybgaer0h232Ka4F9ktmn2ED4YDt3ZjJKYQTqo7lfq5iYamW/W1al9YVLgudUq7wsCFNd5KMSVvUolMpQKBgDXvEqLAdUHZA3des9zI1S/LWZytE822XyhYhvIBoi5YngDgL6IKXjbEyW5ejnL2kKtDgvb8dqmpcI3QJAOODzgB+78B5KXYeoq8zNhaLj3lI4jrSuIBIdKcK7LxM3uHAcFSx3MKE82LoIZLSX/tlW+iN4cn551FbNAjLtZsfqUFAoGAZt8ufhod1vjLGTjVF5ycqpj1GEPRZMpHx5ghOeOqut2swMYHLacjdl4aXQ6xtZN8ioffpnF4I0290T33IJFvg+fOQcLY/sok+JK/jpgX4+kfuZZqzdpeVwyw8xmTEB6/b4MKr5cs7nOVgRmiZ6QM5Ms2XHMx6RMzWzSN7cUB2gg=";
	
	
	// 支付宝应用公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    //public static String alipay_public_key = "MII2019/10/10BIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtRH55u05ERvaf6YjygWtlw+iLWuozLLuQQ0mbfEVWOJQbELuLe5T9jy6RaOGrsjkF79xfn5ghLcc+SOJ7r7arZ0CnvsrGZz3UebwWQNt4TbPKqEiN7TmeeJa2Olh8v9ST2AIMD/+37qMC3aUm3hvt7zAg3o7n/j49t2uaHHkOHhW0Rj6uLZHgvWFMfTBDpjDQ72YkO56MwN4YBbLg3rzooi0UGtyfHBJTtVwIDzmviWBldu1ejVYdskdtXx/x+ZHwgXJKrq8h0P6zBo8k76zBz9Hv55O5congDUMZMT7Xhfyy7QV15AoZnBcYvOIAtJ3blctAd/WPxWJ44FYG/K+9QIDAQAB";
    
     public static String alipay_public_key = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDIgHnOn7LLILlKETd6BFRJ0GqgS2Y3mn1wMQmyh9zEyWlz5p1zrahRahbXAfCfSqshSNfqOmAQzSHRVjCqjsAw1jyqrXaPdKBmr90DIpIxmIyKXv4GGAkPyJ/6FTFY99uhpiq0qadD/uSzQsefWo0aTvP/65zi3eof7TcZ32oWpwIDAQAB";
    
	// 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
    // http://2snf5n.natappfree.cc/alipay.trade.page.pay-JAVA-UTF-8/notify_url.jsp
	public static String notify_url = "http://localhost:8080/alipay.trade.page.pay-JAVA-UTF-8/ReturnServlet?method=notify_url";

	// 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	// http://2snf5n.natappfree.cc/alipay.trade.page.pay-JAVA-UTF-8/return_url.jsp
	public static String return_url = "http://localhost:8080/alipay.trade.page.pay-JAVA-UTF-8/ReturnServlet?method=return_url";

	// 签名方式
	public static String sign_type = "RSA2";
	
	// 字符编码格式
	public static String charset = "utf-8";
	
	// 支付宝网关
	public static String gatewayUrl = "https://openapi.alipaydev.com/gateway.do";
	
	// 支付宝网关     日志                                                        
	public static String log_path = "D:\\";


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

    /** 
     * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
     * @param sWord 要写入日志里的文本内容
     */
    public static void logResult(String sWord) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer.write(sWord);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

